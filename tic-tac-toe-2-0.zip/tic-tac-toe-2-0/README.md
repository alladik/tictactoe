# Tic tac toe 2.0

A Pen created on CodePen.io. Original URL: [https://codepen.io/alladik/pen/xxjEjmM](https://codepen.io/alladik/pen/xxjEjmM).

